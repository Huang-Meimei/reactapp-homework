export const MUSIC_LIST = [
	{
		id: 1,
		title: '天使中的魔鬼',
		artist: '田馥甄',
		file: 'http://f3.htqyy.com/play9/329/mp3/5',
		cover: 'http://oj4t8z2d5.bkt.clouddn.com/%E9%AD%94%E9%AC%BC%E4%B8%AD%E7%9A%84%E5%A4%A9%E4%BD%BF.jpg'
	}, {
		id: 2,
		title: '风继续吹',
		artist: '张国荣',
		file: 'http://oj4t8z2d5.bkt.clouddn.com/%E9%A3%8E%E7%BB%A7%E7%BB%AD%E5%90%B9.mp3',
		cover: 'http://oj4t8z2d5.bkt.clouddn.com/%E9%A3%8E%E7%BB%A7%E7%BB%AD%E5%90%B9.jpg'
	}

];
